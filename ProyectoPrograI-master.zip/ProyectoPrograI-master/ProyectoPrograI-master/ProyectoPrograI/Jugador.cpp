#include "Jugador.h"

Jugador::Jugador() {

}

Jugador::~Jugador() {

}

Carta* Jugador::pedirCarta() {

}