#include"Carta.h"

Carta::Carta()
{

}

Carta::~Carta()
{

}

int Carta::getValor()
{

}

int Carta::getPalo()
{

}

void Carta::Voltear()
{

}