#include "JugadorGenerico.h"

JugadorGenerico::JugadorGenerico()
{

}

JugadorGenerico::~JugadorGenerico()
{

}

Carta* JugadorGenerico::pedirCarta()
{

}

bool JugadorGenerico::sePaso()
{

}