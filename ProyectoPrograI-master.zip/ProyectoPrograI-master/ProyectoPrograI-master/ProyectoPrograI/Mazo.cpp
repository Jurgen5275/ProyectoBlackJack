#include "Mazo.h"

Mazo::Mazo() {

}

Mazo::~Mazo() {

}

void Mazo::inicializar() {

}

void Mazo::barajar() {

}

Carta* Mazo::tomarCarta() {

}