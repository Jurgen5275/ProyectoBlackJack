#ifndef CARTA_H
#define CARTA_H

class Carta
{
public:
	Carta();
	int getValor();
	int getPalo(); 
	void Voltear();
	~Carta();

private:
	enum palo { Corazones, Diamantes, Treboles, Espadas };
	enum valor { Dos = 2, Tres, Cuatro, Cinco, Seis, Siete, Ocho, Nueve, Diez, Jota, Reina, Rey, As };
	bool bocaAbajo;
};



#endif