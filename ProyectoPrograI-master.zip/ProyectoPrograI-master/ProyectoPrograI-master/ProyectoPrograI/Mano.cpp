#include"Mano.h"

Mano::Mano(){
}

Mano::~Mano() {

}

void Mano::agregarCarta(Mazo*) {

}

void Mano::limpiar() {

}

int Mano::getPuntos() {

}