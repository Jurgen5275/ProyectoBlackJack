#include "Nodo.h"

Nodo::Nodo() {

}

Nodo::~Nodo() {

}

Nodo* Nodo::getNext() {

}