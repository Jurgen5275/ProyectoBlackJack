#include"Dealer.h"

Dealer::Dealer() {

}

Dealer::~Dealer() {

}

Carta* Dealer::pedirCarta() {

}

void Dealer::volteaSegunda() {

}
